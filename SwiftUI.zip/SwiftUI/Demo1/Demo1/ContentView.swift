//
//  ContentView.swift
//  Demo1
//
//  Created by Mirant Patel on 09/10/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            
            HStack {
                Text("Hello!")
                    .font(.subheadline)
                    .fontWeight(.regular)
                    .foregroundColor(Color.init("mike"))
                    .multilineTextAlignment(.center)
                    .padding(.all)
                Text("Hello check!")
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
