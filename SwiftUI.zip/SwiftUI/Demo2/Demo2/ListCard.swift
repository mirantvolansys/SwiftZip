//
//  ListCard.swift
//  Demo2
//
//  Created by Mirant Patel on 24/10/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct ListCard: View {
    
    var arrayData = [cardData]()

    init() {
        addData()
    }

    struct cardData {
      let id: Int
      let image: String
      let category: String
      let heading: String
      let author: String
    }

    mutating func addData() {
        arrayData.append(cardData(id: 0, image: "1", category: "SwiftUI", heading: "Drawing a Border with Rounded Corners", author: "Simon Ng"))
        arrayData.append(cardData(id: 1, image: "2", category: "Swift", heading: "Drawing a Border with Rounded Corners", author: "Mi Ng"))
        arrayData.append(cardData(id: 2, image: "3", category: "Objective C", heading: "Drawing a Border with Rounded Corners", author: "Mike"))
        arrayData.append(cardData(id: 3, image: "4", category: "Flutter", heading: "Drawing a Border with Rounded Corners", author: "Mine Ng"))
    }

    var body: some View {
        
        List(arrayData, id: \.id) { card in
            CardUI(image: card.image, category: card.category, heading: card.heading, author: card.author)
            
            .onTapGesture {
                print(card.category)
            }
        }
        .onAppear { UITableView.appearance().separatorStyle = .none } .onDisappear { UITableView.appearance().separatorStyle = .singleLine }
    }
}

struct ListCard_Previews: PreviewProvider {
    static var previews: some View {
        ListCard()
    }
}
