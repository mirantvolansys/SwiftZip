//
//  ContentView.swift
//  Demo3
//
//  Created by Mirant Patel on 04/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @State var quantity: Int = 0
    @State var progress: Float = 0.0
    @State var error: AlertError?
    @State var isModal: Bool = false
    
    @State var detail: ModalDetail?
    
    @State var isSheet: Bool = false

    var actionSheet: ActionSheet {
        ActionSheet(title: Text("Action"),
                    message: Text("Description"),
                    buttons: [
                        .default(Text("OK"), action: {
                            
                        }),
                        .destructive(Text("Delete"), action: {
                            
                        })
                    ]
        )
    }

    struct ModalDetail: Identifiable {
        var id: String {
            return body
        }
        
        let body: String
    }
    
    func modal(detail: String) -> some View {
        Text(detail)
    }
    
    var sliderClosedRange: ClosedRange<Float> {
        return 0.0...100.0
    }
    
    var modal: some View {
        Text("Mike")
    }
    
    func alert(reason: String) -> Alert {
        Alert(title: Text("Error"),
                message: Text(reason),
                dismissButton: .default(Text("OK"))
        )
    }

    struct AlertError: Identifiable {
        var id: String {
            return reason
        }
        
        let reason: String
    }
    
    var body: some View {
        
        Button("Action Sheet") {
            self.isSheet = true
        }.actionSheet(isPresented: $isSheet, content: {
            self.actionSheet
    })
        
//        Button("Modal") {
//            self.detail = ModalDetail(body: "Detail")
//        }.sheet(item: $detail, content: { detail in
//            self.modal(detail: detail.body)
//        })
        
//        Button("Modal") {
//            self.isModal = true
//        }.sheet(isPresented: $isModal, content: {
//            self.modal
//        })
        
//        Button("Alert Error") {
//            self.error = AlertError(reason: "Reason")
//        }.alert(item: $error, content: { error in
//            alert(reason: error.reason)
//        })
        
//        TabView {
//            Text("First View")
//                .font(.title)
//                .tabItem({
//                    Text("Round")
//                    Image(systemName: "circle")
//                })
//                .tag(0)
//            Text("Second View")
//                .font(.title)
//                .tabItem({
//                    Text("Square")
//                    Image(systemName: "square")
//                })
//                .tag(1)
//        }
        
//        NavigationView {
//            List {
//                NavigationLink("Go to detail", destination: Text("New Detail"))
//                NavigationLink("Go to detail1", destination: Text("New Detail"))
//            }
//            .navigationBarTitle("Master")
//            Text("Placeholder for Detail")
//        }.navigationViewStyle(StackNavigationViewStyle())
        
//        NavigationView {
//            Form {
//                Section {
//                    Text("Plain Text")
//                    Stepper(value: $quantity, in: 0...10, label: { Text("Quantity") })
//                }
//                Section {
//                    Text("Plain Text")
//                    Stepper(value: $quantity, in: 0...10, label: { Text("Quantity") })
//                }
//            }
//        }
        
        
//        NavigationView {
//            List {
//                Section(header: Text("UIKit"), footer: Text("We will miss you")) {
//                    Text("UITableView")
//                    Text("UITableView1")
//                }
//
//                Section(header: Text("SwiftUI"), footer: Text("A lot to learn")) {
//                    Text("List")
//                    Text("List1")
//                }
//            .listStyle(PlainListStyle())
//            }
//        .navigationBarTitle("Mike")
//        }
        //        ZStack {
        //            Text("Hello")
        //                .padding(10)
        //                .background(Color.red)
        //                .opacity(0.8)
        //            Text("World")
        //                .padding(20)
        //                .background(Color.red)
        //                .offset(x: 30, y: 30)
        //        }
        
        
        //        Stepper("Quantity \(quantity)", value: $quantity, in: 0...10)
        
        //        VStack {
        //            HStack {
        //                Image(systemName: "sun.min")
        //                Slider(value: $progress, in: sliderClosedRange, label: {
        //                    Text("Mike")
        //                })
        //                Image(systemName: "sun.max.fill")
        //            }.padding()
        //
        //            Text(String(format: "%.2f", Float(progress)))
        //        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

