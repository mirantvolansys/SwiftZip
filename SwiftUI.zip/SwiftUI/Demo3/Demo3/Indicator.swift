//
//  Indicator.swift
//  Demo3
//
//  Created by Mirant Patel on 06/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import UIKit
import SwiftUI


struct Indicator: UIViewRepresentable {
    @Binding var isAnimating: Bool
    
    func makeUIView(context: Context) -> UIActivityIndicatorView {
        let v = UIActivityIndicatorView()
        
        return v
    }
    
    func updateUIView(_ uiView: UIActivityIndicatorView, context: Context) {
        if isAnimating {
            uiView.startAnimating()
        } else {
            uiView.stopAnimating()
        }
    }
}
