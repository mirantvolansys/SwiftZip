//
//  AnimateWithExtension.swift
//  DemoAnimationAnimatableModifier
//
//  Created by Mirant Patel on 12/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct AnimateWithExtension: View {
    
    @State var scale: CGFloat = 1
    
    var body: some View {
        Circle()
        .scaleEffect(scale)
        .animateForever(autoreverses: true) { self.scale = 0.5 }
    }
}


extension View {
    func animateForever(using animation: Animation = Animation.easeInOut(duration: 1), autoreverses: Bool = false, _ action: @escaping () -> Void) -> some View {
        let repeated = animation.repeatForever(autoreverses: autoreverses)

        return onAppear {
            withAnimation(repeated) {
                action()
            }
        }
    }
}

struct AnimateWithExtension_Previews: PreviewProvider {
    static var previews: some View {
        AnimateWithExtension()
    }
}
