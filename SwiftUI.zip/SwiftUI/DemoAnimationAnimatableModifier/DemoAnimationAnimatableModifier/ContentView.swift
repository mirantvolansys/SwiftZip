//
//  ContentView.swift
//  DemoAnimationAnimatableModifier
//
//  Created by Mirant Patel on 12/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @State var rotation = 0.0
    
//    @State var scale: CGFloat = 1
    
    var body: some View {
        Rectangle()
        .fill(Color.red)
        .frame(width: 200, height: 200)
        .rotationEffect(.degrees(rotation))
            .animation(Animation.easeInOut(duration: 3).delay(0.5))
        .onTapGesture {
            self.rotation += 360
        }
        
//        Circle()
//        .scaleEffect(scale)
//        .onAppear {
//            let baseAnimation = Animation.easeInOut(duration: 0.5)
//            let repeated = baseAnimation.repeatForever(autoreverses: true)
//
//            return withAnimation(repeated) {
//                self.scale = 0.5
//            }
//        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
