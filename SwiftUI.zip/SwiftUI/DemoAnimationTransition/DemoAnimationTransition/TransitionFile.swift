//
//  TransitionFile.swift
//  DemoAnimationTransition
//
//  Created by Mirant Patel on 11/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct TransitionFile: View {
    
    @State private var showDetails = false
    
    var body: some View {
        VStack {
            Button(action: {
                withAnimation {
                    self.showDetails.toggle()
                }
            }) {
                Text("Tap to show details")
            }

            if showDetails {
                //1. Display
                //                Text("Details go here.")
                
                //2. Move
//                Text("Details go here.")
//                .transition(.move(edge: .bottom))
                
                //3. Slide
//                                Text("Details go here.")
//                                .transition(.slide)
                
                //4. Scale
                                Text("Details go here.")
                                .transition(.scale)
            }
        }
    }
}

struct TransitionFile_Previews: PreviewProvider {
    static var previews: some View {
        TransitionFile()
    }
}
