//
//  AnyTranFile.swift
//  DemoAnipairAnytransition
//
//  Created by Mirant Patel on 12/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct AnyTranFile: View {
    var body: some View {
        Text("Details go here.")
        .transition(.moveAndScale)
    }
}

extension AnyTransition {
    static var moveAndScale: AnyTransition {
        AnyTransition.move(edge: .bottom).combined(with: .scale)
    }
}

struct AnyTranFile_Previews: PreviewProvider {
    static var previews: some View {
        AnyTranFile()
    }
}
