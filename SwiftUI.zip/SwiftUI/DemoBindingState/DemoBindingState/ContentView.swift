//
//  ContentView.swift
//  DemoBindingState
//
//  Created by Mirant Patel on 19/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State var rate:Rating
    
    var body: some View {
        VStack(alignment: .trailing) {
          Text(self.rate.descriptionForRating())
          RatePicker(rate: $rate)
        }.padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ForEach(Rating.allCases, id: \.self) { rate in
              ContentView(rate: rate)
            }
        }
    }
}
