//
//  RateModel.swift
//  DemoBindingState
//
//  Created by Mirant Patel on 19/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

enum Rating: Int,CaseIterable {
  case noRate = 0
  case terrible
  case bad
  case hmmm
  case good
  case brilliant
  
  func descriptionForRating() -> String {
    switch self {
    case .noRate:
      return "Please rate:"
    case .terrible:
      return "Terrible"
    case .bad:
      return "Not good, not terrible"
    case .hmmm:
      return "Hmm..."
    case .good:
      return "Gooood"
    case .brilliant:
      return "Brilliant!"
    }
  }
}
