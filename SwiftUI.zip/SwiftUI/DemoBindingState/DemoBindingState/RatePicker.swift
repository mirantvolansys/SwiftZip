//
//  RatePicker.swift
//  DemoBindingState
//
//  Created by Mirant Patel on 19/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct RatePicker: View {
    
    @Binding var rate:Rating
    
    func starButton(index:Int) -> some View {
      let imageName = index <= rate.rawValue ? "star.fill" : "star"
      let color:Color = index <= rate.rawValue ? .yellow : .gray
      
      return
        Button(action: {
          if self.rate.rawValue == index {
            self.rate = Rating(rawValue: 0)!
          } else {
            self.rate = Rating(rawValue: index)!
          }
        }) {
          Image(systemName:imageName)
            .imageScale(.large)
            .foregroundColor(color)
            .frame(width:24, height: 24)
      }
    }
    
    var body: some View {
        HStack {
            ForEach((1..<6)) { id in
                self.starButton(index: id)
            }
        }
    }
}

//struct RatePicker_Previews: PreviewProvider {
//    static var previews: some View {
//        RatePicker(rate: rate)
//    }
//}
