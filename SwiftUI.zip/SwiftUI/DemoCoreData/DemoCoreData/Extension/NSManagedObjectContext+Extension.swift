//
//  NSManagedObjectContext+Extension.swift
//  DemoCoreData
//
//  Created by Mirant Patel on 20/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import Foundation
import UIKit
import CoreData

extension NSManagedObjectContext {
    static var current : NSManagedObjectContext {
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        return appdelegate.persistentContainer.viewContext
    }
}
