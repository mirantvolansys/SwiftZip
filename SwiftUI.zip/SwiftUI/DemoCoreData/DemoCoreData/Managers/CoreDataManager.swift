//
//  CoreDataManager.swift
//  DemoCoreData
//
//  Created by Mirant Patel on 20/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import Foundation
import CoreData

class CoreDataManager{
    static let shared = CoreDataManager(moc: NSManagedObjectContext.current)
    
    var moc : NSManagedObjectContext
    
    private init(moc : NSManagedObjectContext) {
        self.moc = moc
    }
    
    func deleteOrder(name : String){
        do{
            if let order : Order = getOrderSpecific(name: name) {
                self.moc.delete(order)
                try self.moc.save()
            }
        } catch let error as NSError{
            print(error)
        }
    }
    
    func getOrderSpecific(name : String) -> Order {
        var orders = [Order]()
        
        let orderRequest : NSFetchRequest<Order> = Order.fetchRequest()
        orderRequest.predicate = NSPredicate(format: "name == %@", name)
        
        do{
            orders = try self.moc.fetch(orderRequest)
        } catch let error as NSError{
            print(error)
        }
        
        return orders.first!
    }
    
    func getOrder() -> [Order] {
        var orders = [Order]()
        
        let orderRequest : NSFetchRequest<Order> = Order.fetchRequest()
        
        do{
            orders = try self.moc.fetch(orderRequest)
        } catch let error as NSError{
            print(error)
        }
        
        return orders
    }
    
    func saveOrder(name:String,type:String) {
        let order = Order(context: self.moc)
        order.name = name
        order.type = type
        
        do{
            try self.moc.save()
        } catch let error as NSError{
            print(error)
        }
    }
}
