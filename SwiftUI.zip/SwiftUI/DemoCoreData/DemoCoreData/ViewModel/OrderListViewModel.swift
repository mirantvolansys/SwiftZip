//
//  OrderListViewModel.swift
//  DemoCoreData
//
//  Created by Mirant Patel on 20/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import Foundation
import SwiftUI
import Combine
import CoreData

class OrderListViewModel : ObservableObject {
    
    @Published var orders = [OrderViewModel]()
    
    init() {
        fetchAllOrders()
    }
    
    func deleteOrder(order : OrderViewModel) {
        CoreDataManager.shared.deleteOrder(name: order.name)
        fetchAllOrders()
    }
    
    func fetchAllOrders() {
        self.orders = CoreDataManager.shared.getOrder().map(OrderViewModel.init)
        print(self.orders)
    }
}

class OrderViewModel {
    var name = ""
    var type = ""
    
    init(order : Order) {
        self.name = order.name!
        self.type = order.type!
    }
}
