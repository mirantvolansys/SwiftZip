//
//  AddOrView.swift
//  DemoCoreData
//
//  Created by Mirant Patel on 20/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct AddOrView: View {
    
    @State var addOrderVM = AddOrderViewModel()
    @Binding var isPresented : Bool
    
    var body: some View {
        NavigationView{
            Group {
                VStack {
                    TextField("Enter name", text: self.$addOrderVM.name)
                    
                    Picker(selection: self.$addOrderVM.type, label: Text("")) {
                        Text("Cappuccino").tag("cap")
                        Text("Regular").tag("reg")
                        Text("Expresso").tag("exp")
                    }.pickerStyle(SegmentedPickerStyle())
                    
                    Button("Order") {
                        self.addOrderVM.saveOrder()
                        self.isPresented = false
                        self.addOrderVM = AddOrderViewModel()
                        
                    }.padding(8)
                        .foregroundColor(Color.white)
                        .background(Color.green)
                        .cornerRadius(10)
                }
            }.padding(8)
            
            .navigationBarTitle("Add Order")
        }
    }
}

struct AddOrView_Previews: PreviewProvider {
    static var previews: some View {
        AddOrView(isPresented: .constant(false))
    }
}
