//
//  ContentView.swift
//  DemoEnvironmentOnly
//
//  Created by Mirant Patel on 21/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Hello")
            HStack {
                DumpingEnvironment(content: Text("Beautiful"))
                Text("World")
            }
        }.font(.title)
    }
}

struct DumpingEnvironment<V: View>: View {
    @Environment(\.self) var env
    let content: V
    var body: some View {
        dump(env)
        return content
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
