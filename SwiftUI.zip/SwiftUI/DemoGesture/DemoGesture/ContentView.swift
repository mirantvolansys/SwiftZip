//
//  ContentView.swift
//  DemoGesture
//
//  Created by Mirant Patel on 07/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct ContentView : View {
    @State private var offset: CGSize = .zero
    @GestureState var isLongPressed = false

    var body: some View {
        let longPressAndDrag = LongPressGesture()
            .updating($isLongPressed) { value, state, transition in
                state = value
        }.simultaneously(with: DragGesture()
            .onChanged { self.offset = $0.translation }
            .onEnded { _ in self.offset = .zero }
        )

        return Rectangle()
            .fill(isLongPressed ? Color.purple : Color.red)
            .frame(width: 100, height: 100)
            .cornerRadius(8)
            .shadow(radius: 8)
            .padding()
            .scaleEffect(isLongPressed ? 1.5 : 1)
            .offset(x: offset.width, y: offset.height)
            .gesture(longPressAndDrag)
            .animation(.easeInOut)
    }
}
