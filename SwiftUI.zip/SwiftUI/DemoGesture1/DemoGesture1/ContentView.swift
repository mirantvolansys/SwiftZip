//
//  ContentView.swift
//  DemoGesture1
//
//  Created by Mirant Patel on 26/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @State var scale: CGFloat = 1.0
    @State private var didTap: Bool = false
    @State private var rotateState: Double = 0
    
    var body: some View {
        //        magnifyView()
        //        tapView()
//        dragView()
//        longPressView()
        rotationView()
    }
    
    func magnifyView() -> some View {
        Image("apple-logo")
            .resizable()
            .scaleEffect(scale)
            .frame(width: 100, height: 100)
            // 3.
            .gesture(MagnificationGesture()
                .onChanged { value in
                    self.scale = value.magnitude
                }
        )
    }
    
    func tapView() -> some View {
        Text("Tap me")
            .frame(minWidth:0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
            // 3.
            .gesture(TapGesture()
                .onEnded {
                    self.didTap.toggle()
                }
        )
            // 4.
            .background(didTap ? Color.blue : Color.red)
    }
    
    func longPressView() -> some View {
        Image("apple-logo")
            .gesture(
                LongPressGesture(minimumDuration: 2)
                    .onEnded { _ in
                        print("long end!")
                }
        )
    }
    
    func dragView() -> some View {
        Image("apple-logo")
            .gesture(
                DragGesture(minimumDistance: 50)
                    .onEnded { _ in
                        print("Dragged!")
                }
                .onChanged({ value in
                    print(value.location)
                })
        )
    }
    
    func rotationView() -> some View {
        Image("apple-logo")
        // 3.
        .rotationEffect(Angle(degrees: self.rotateState))
        // 4.
        .gesture(RotationGesture()
            .onChanged { value in
                self.rotateState = value.degrees
            }
        )
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
