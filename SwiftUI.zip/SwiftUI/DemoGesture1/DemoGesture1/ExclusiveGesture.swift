//
//  ExclusiveGesture.swift
//  DemoGesture1
//
//  Created by Mirant Patel on 27/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct ExclusiveGesture: View {
    
    @State var viewState = CGSize.zero
    @State var canBeDragged = false
    @State var translation = CGSize.zero
    
    var body: some View {
        
        let longTapGesture = LongPressGesture(minimumDuration: 1.0).onEnded { _ in
            self.canBeDragged = true
        }
        
        let dragGesture = DragGesture().onChanged { (value) in
            self.translation = value.translation
            self.canBeDragged = false
        }.onEnded { (value) in
            self.viewState.width += value.translation.width
            self.viewState.height += value.translation.height
            self.translation = .zero
        }
        
        let dragBeforeLongTapGesture = longTapGesture.exclusively(before: dragGesture)
        
        return Circle()
            .fill(Color.blue)
            .overlay(canBeDragged ? Circle().stroke(Color.red , lineWidth: 4) : nil)
            .overlay(canBeDragged ? Circle().stroke(Color.orange , lineWidth: 2) : nil)
            .frame(width: 100, height: 100, alignment: .center)
            .offset(x: viewState.width + translation.width, y: viewState.height + translation.height)
            .shadow(radius: canBeDragged ? 8 : 0)
            .gesture(dragBeforeLongTapGesture)
        
    }
}

struct ExclusiveGesture_Previews: PreviewProvider {
    static var previews: some View {
        ExclusiveGesture()
    }
}
