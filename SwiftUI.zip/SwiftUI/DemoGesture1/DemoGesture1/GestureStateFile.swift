//
//  GestureStateFile.swift
//  DemoGesture1
//
//  Created by Mirant Patel on 27/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct GestureStateFile: View {
    
    @GestureState var dragAmount = CGSize.zero
    
    var body: some View {
        Image("apple-logo")
        .offset(dragAmount)
        .gesture(
            DragGesture().updating($dragAmount) { value, state, transaction in
                state = value.translation
            }
        )
    }
}

struct GestureStateFile_Previews: PreviewProvider {
    static var previews: some View {
        GestureStateFile()
    }
}
