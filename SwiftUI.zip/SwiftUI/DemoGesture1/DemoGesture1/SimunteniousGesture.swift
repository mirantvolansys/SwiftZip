import SwiftUI

struct BorderChange: ViewModifier {
    enum BorderColor: CaseIterable {
        case black
        case blue
        case red
        
        func color() -> Color {
            switch self {
            case .black:
                return .black
            case .blue:
                return .blue
            case .red:
                return .red
            }
        }
        
        func next() -> BorderColor {
            // 1
            let allColors = BorderColor.allCases

            // 2
            if let lastIndex = allColors.lastIndex(of: self) {
                
                // 3
                if lastIndex + 1 == allColors.count {
                    return allColors[0]
                }
                
                // 4
                return allColors[lastIndex + 1]
            }

            // 5
            return self
        }
    }
    
    @State var currentState = BorderColor.black
    
    func body(content: Content) -> some View {
        return content.border(self.currentState.color(),
                              width: 5).simultaneousGesture(TapGesture().onEnded({
            self.currentState = self.currentState.next()
        }))
    }
}

struct SimunteniousGesture: View {
    @State var degree : Double = 0
    @State var scale : CGFloat = 1.0
    
    var body: some View {
        
        let magnificationGesture = MagnificationGesture().onChanged { (value) in
            self.scale = value.magnitude
        }.onEnded { _ in
            self.scale = 1.0
        }
        
        let rotationGesture = RotationGesture().onChanged { (value) in
            self.degree = value.degrees
        }.onEnded { _ in
            self.degree = 0
        }
        
        let magnituteAndDrag = magnificationGesture.simultaneously(with: rotationGesture)
        
        return Rectangle().frame(width: 100, height: 100, alignment: .center).gesture(magnituteAndDrag).rotationEffect(Angle(degrees: degree)).scaleEffect(scale).animation(.easeInOut)
    }
}

struct SimunteniousGesture_Previews: PreviewProvider {
    static var previews: some View {
        SimunteniousGesture()
    }
}
