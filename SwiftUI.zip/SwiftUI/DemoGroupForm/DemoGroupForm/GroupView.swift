//
//  GroupView.swift
//  DemoGroupForm
//
//  Created by Mirant Patel on 08/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct GroupView: View {
    var body: some View {
        VStack {
            Group {
                Text("Hello World !")
                Text("Hello World !")
            }
            .padding(10.0)
            .border(Color.red, width: 1.0)
            Group {
                Text("Hello World !")
                Text("Hello World !")
            }
            .padding(10.0)
            .border(Color.green, width: 1.0)
            Group {
                Text("Hello World !")
                Text("Hello World !")
            }
            .padding(10.0)
            .border(Color.blue, width: 1.0)
        }.navigationBarTitle(Text("Group"))
    }
}

struct GroupView_Previews: PreviewProvider {
    static var previews: some View {
        GroupView()
    }
}


