//
//  ContentView.swift
//  DemoShapes
//
//  Created by Mirant Patel on 12/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Path { path in
            path.move(to: CGPoint(x: 20, y: 20))
            path.addLine(to: CGPoint(x: 20, y: 300))
            path.addLine(to: CGPoint(x: 300, y: 300))
            path.addLine(to: CGPoint(x: 300, y: 20))
        }.fill(LinearGradient(
            gradient: .init(colors: [Color.blue,Color.red]), startPoint: .init(x: 0, y: 0), endPoint: .init(x: 1, y: 1)
        ))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
