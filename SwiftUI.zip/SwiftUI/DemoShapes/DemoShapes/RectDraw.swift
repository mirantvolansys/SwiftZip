//
//  RectDraw.swift
//  DemoShapes
//
//  Created by Mirant Patel on 12/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct RectDraw: View {
    var body: some View {
//        Rectangle().frame(width: 150, height: 150, alignment: Alignment.bottom).foregroundColor(Color.green)
        
//        Circle().frame(width: 150, height: 150, alignment: Alignment.bottom).foregroundColor(Color.green)
        
//        Ellipse().frame(width: 300, height: 150, alignment: Alignment.bottom).foregroundColor(Color.green)
        
        Capsule().frame(width: 300, height: 150, alignment: Alignment.bottom).foregroundColor(Color.green)
        
//        RoundedRectangle(cornerRadius: 10, style: .continuous).frame(width: 150, height: 250, alignment: Alignment.bottom).foregroundColor(Color.green)
        
    }
}

struct RectDraw_Previews: PreviewProvider {
    static var previews: some View {
        RectDraw()
    }
}
