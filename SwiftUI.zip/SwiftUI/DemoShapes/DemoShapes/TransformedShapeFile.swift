//
//  TransformedShapeFile.swift
//  DemoShapes
//
//  Created by Mirant Patel on 14/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct TransformedShapeFile: View {
    var body: some View {
//        ScaledShape(shape: Rectangle(), scale: CGSize(width: 0.5, height: 0.5),anchor: UnitPoint(x: 0, y: 0)).foregroundColor(Color.red)
        
//        RotatedShape(shape: Rectangle(), angle: Angle(degrees: 65))
        
//        OffsetShape(shape: Rectangle(), offset: CGSize(width: 250, height: 550))
        
        TransformedShape(shape: Rectangle(), transform: CGAffineTransform(a: 30, b: 50, c: 5, d: 150, tx: 15, ty: 15))
    }
}

struct TransformedShapeFile_Previews: PreviewProvider {
    static var previews: some View {
        TransformedShapeFile()
    }
}
