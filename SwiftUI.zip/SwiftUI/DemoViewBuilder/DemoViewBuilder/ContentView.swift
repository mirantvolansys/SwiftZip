//
//  ContentView.swift
//  DemoViewBuilder
//
//  Created by Mirant Patel on 07/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @State var mike : String = ""
    
    var body: some View {
        Passthrough {
            Text("one")
            Text("two")
            Text("three")
            TextField("Mike", text: self.$mike)
        }
    }
}

struct Passthrough<Content>: View where Content: View {

    let content: () -> Content

    init(@ViewBuilder content: @escaping () -> Content) {
        self.content = content
    }

    var body: some View {
        content()
    }

}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
