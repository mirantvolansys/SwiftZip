//
//  ContentView.swift
//  DemoUIVIewRepresent
//
//  Created by Mirant Patel on 06/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var users = ["Paul", "Taylor", "Adele"]

    var body: some View {
        NavigationView {
            List {
                ForEach(users, id: \.self) { user in
                    Text(user)
                }
                .onDelete(perform: delete)
                .onMove(perform: movePlace)
            }
            .navigationBarItems(trailing: EditButton())
        }
        
//        Text("Hello World")
//        .fontWeight(.bold)
//        .font(.title)
//        .padding()
//        .background(Color.purple)
//        .cornerRadius(40)
//        .foregroundColor(.white)
//        .padding(10)
//        .overlay(
//            RoundedRectangle(cornerRadius: 40)
//                .stroke(Color.purple, lineWidth: 5)
//        )
    }

    func delete(at offsets: IndexSet) {
        
        print(offsets)
//        users.remove(atOffsets: offsets)
    }
    
    func movePlace(from source: IndexSet, to destination: Int) {
        print(source,destination)
    }
}
