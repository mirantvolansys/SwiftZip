//
//  ContentView.swift
//  ObservableObject
//
//  Created by Mirant Patel on 19/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var settings = UserSettings()

    @State var selection: Int? = nil
    
    var body: some View {
        
        NavigationView {
            VStack {
                
                Text("Your score is \(settings.score)")
                
                NavigationLink(destination: ContentView1(), tag: 1, selection: $selection) {
                    Button("Increase Score") {
                        self.settings.score += 1
                        if(self.settings.score < 5) {
                            return self.selection = 0
                        } else {
                            return self.selection = 1
                        }
                    }
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
