//
//  UserSettings.swift
//  ObservableObject
//
//  Created by Mirant Patel on 19/11/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

class UserSettings: ObservableObject {
    @Published var score = 0
}
