---
name: SwiftUI issue
about: Describe and give feedback on problems you have encountered.
title: SwiftUI issue
labels: question
assignees: ''

---

## Version
macOS version:

Xcode version: 

## Description

Describe your problem:
