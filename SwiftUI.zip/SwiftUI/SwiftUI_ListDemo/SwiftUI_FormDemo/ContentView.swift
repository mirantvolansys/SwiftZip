//
//  ContentView.swift
//  SwiftUI_FormDemo
//
//  Created by Mirant Patel on 22/10/19.
//  Copyright © 2019 Mirant Patel. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @State var name: String = ""
    
    var body: some View {
        NavigationView(content: {
            List{
                Image("chicken")
                    .resizable()
                    .scaledToFill()
                    .frame(height: 300)
                    .clipped()
                
                VStack(alignment: .leading, spacing: 10.0) {
                    LabelTextField(label: "NAME", placeHolder: "Enter Name")
                    LabelTextField(label: "TYPE", placeHolder: "Enter Type")
                    LabelTextField(label: "ADDRESS", placeHolder: "Enter Address")
                    LabelTextField(label: "PHONE", placeHolder: "Enter Phone")
                    LabelTextField(label: "DESCRIPTION", placeHolder: "Enter Discription")
                }
                
                RoundedButton().padding(.top, 20.0)
            }.padding(.top, 10.0).listRowInsets(EdgeInsets())
                
                
                .navigationBarTitle(Text("New Restaurant"), displayMode: .automatic)
                .navigationBarItems(trailing: Button(action: {}, label: {
                    Text("Cancel")
                })
        
            )
        })
    }
}


struct LabelTextField : View {
    var label: String
    var placeHolder: String
    @State var name: String = ""
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10.0) {
            Text(label)
            
            TextField(placeHolder, text: $name)
                .padding(EdgeInsets(top: 10, leading: 0, bottom: 10, trailing: 0)).background(Color(red: 239.0/255.0, green: 243.0/255.0, blue: 244.0/255.0, opacity: 1.0))
                .cornerRadius(5.0)
                .border(Color.black)
            
        }.padding(.all, 10.0)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        //        Group {
        ContentView()
        //        RoundedButton().previewLayout(.sizeThatFits)
        //        }
    }
}

struct RoundedButton : View {
    var body: some View {
        Button(action: {}) {
            HStack{
                Spacer()
                Text("Save").font(.headline).foregroundColor(Color.white)
                Spacer()
            }
        }.padding(.vertical, 10.0)
            .background(Color.red)
            .cornerRadius(20.0)
            .padding(.horizontal, 50)
    }
}
